#./bin/bash
export TAG=prod-$1

echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Begin to deploy TAG ${TAG}<<<<<<<<<<<<<<<<<<<<<<<<<<"
# Recreate docker images
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    Begin to deploy meetingmonster-service       <<<<<<<<<<<<<<<<<<<<<<<<<<"
docker-compose up -d --force-recreate --no-deps meetingmonster
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    End to deploy meetingmonster-service         <<<<<<<<<<<<<<<<<<<<<<<<<<"
